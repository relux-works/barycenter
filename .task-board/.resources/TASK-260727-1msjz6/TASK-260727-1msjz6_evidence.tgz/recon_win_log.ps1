$ErrorActionPreference="SilentlyContinue"
Write-Output "=== process command line (PID 11572) ==="
(Get-CimInstance Win32_Process -Filter "Name='pulsar-win-amd64.exe'" | Select-Object ProcessId,CommandLine,CreationDate | Format-List | Out-String)
Write-Output "=== pulsar.log (masked 64-hex) ==="
$d = Join-Path $env:APPDATA "Pulsar"
$log = Join-Path $d "pulsar.log"
if (Test-Path $log) {
  $t = Get-Content -Raw $log
  $t = [regex]::Replace($t, "[0-9a-fA-F]{64}", "<REDACTED-64HEX>")
  $t = [regex]::Replace($t, "[0-9a-fA-F]{32,}", "<REDACTED-HEX>")
  Write-Output $t
} else { Write-Output "NO LOG" }
Write-Output "=== search other config dirs ==="
Get-ChildItem -Path (Join-Path $env:LOCALAPPDATA "Pulsar") -Force -ErrorAction SilentlyContinue | Select-Object Name,Length,LastWriteTime | Format-Table -AutoSize | Out-String
