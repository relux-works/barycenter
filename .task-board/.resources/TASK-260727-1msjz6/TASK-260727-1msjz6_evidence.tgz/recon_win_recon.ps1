$ErrorActionPreference="SilentlyContinue"
Write-Output "=== PROCS ==="
Get-Process | Where-Object { $_.ProcessName -match "pulsar|librespot" } | Select-Object ProcessName,Id,StartTime | Format-Table -AutoSize | Out-String
Write-Output "=== SESSIONS ==="
(query user) 2>&1 | Out-String
Write-Output "=== CONFIG DIR (APPDATA\Pulsar) ==="
$d = Join-Path $env:APPDATA "Pulsar"
Write-Output ("dir=" + $d)
if (Test-Path $d) {
  Get-ChildItem -Force $d | Select-Object Name,Length,LastWriteTime | Format-Table -AutoSize | Out-String
} else { Write-Output "MISSING" }
Write-Output "=== credentials.v1.dpapi ==="
$c = Join-Path $d "credentials.v1.dpapi"
if (Test-Path $c) {
  $fi = Get-Item -Force $c
  Write-Output ("PRESENT bytes=" + $fi.Length + " mtime=" + $fi.LastWriteTime.ToString("o"))
  $h = (Get-FileHash -Algorithm SHA256 $c).Hash
  Write-Output ("sha256=" + $h)
} else { Write-Output "ABSENT" }
