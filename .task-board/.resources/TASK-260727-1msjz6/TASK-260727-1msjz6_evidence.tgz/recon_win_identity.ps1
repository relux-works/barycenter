$ErrorActionPreference="Stop"
Add-Type -AssemblyName System.Security
function FP([string]$s){
  if([string]::IsNullOrEmpty($s)){return "<none>"}
  $sha=[System.Security.Cryptography.SHA256]::Create()
  $h=[BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($s))).Replace('-','').ToLower()
  return "sha256:"+$h.Substring(0,16)
}
$d = Join-Path $env:APPDATA "Pulsar"
$c = Join-Path $d "credentials.v1.dpapi"
$bytes = [System.IO.File]::ReadAllBytes($c)
try {
  $plain = [System.Security.Cryptography.ProtectedData]::Unprotect($bytes,$null,[System.Security.Cryptography.DataProtectionScope]::CurrentUser)
} catch {
  Write-Output ("DECRYPT_FAIL: " + $_.Exception.Message); exit 0
}
# envelope: magic[4]='BCDP', version[1]=1, len[4] LE, then JSON
$magic = [Text.Encoding]::ASCII.GetString($plain[0..3])
$ver = $plain[4]
$len = [BitConverter]::ToUInt32($plain,5)
$json = [Text.Encoding]::UTF8.GetString($plain[9..(9+$len-1)])
# zero plaintext copy asap
[Array]::Clear($plain,0,$plain.Length)
$o = $json | ConvertFrom-Json
Write-Output ("envelope_magic=" + $magic + " version=" + $ver + " payload_len=" + $len)
Write-Output "--- WINDOWS BARYCENTER PUBLIC IDENTITY (secrets as fingerprints only) ---"
Write-Output ("bundle_version = " + $o.version)
Write-Output ("coordinator_origin = " + $o.coordinator_origin)
Write-Output ("recovery_id = " + $o.recovery_id)
if($o.node){
  Write-Output ("node.orbit_id = " + $o.node.orbit_id)
  Write-Output ("node.slot = " + $o.node.slot)
  Write-Output ("node.ws_url = " + $o.node.ws_url)
  Write-Output ("node.node_token_fp = " + (FP $o.node.node_token))
}
if($o.control){
  Write-Output ("control.actor_id = " + $o.control.actor_id)
  Write-Output ("control.orbit_id = " + $o.control.orbit_id)
  Write-Output ("control.role = " + $o.control.role)
  Write-Output ("control.context = " + $o.control.context)
  Write-Output ("control.control_token_fp = " + (FP $o.control.control_token))
}
$json=$null
