# Two distinct Barycenters — public identity evidence (secrets = fingerprints only)
Captured RUN-260727-3a8672 (tester), 2026-07-27T20:30Z–21:05Z UTC. HEAD 0445f3f.

## Mac (this machine) — read from macOS Keychain bundle (public fields; tokens masked)
- store: Keychain svce=works.relux.pulsar acct=onboarding-credential-bundle-v2 (bundle version 2)
- orbit_id=9  slot=a  actor_id=20  role=primary  context=active
- coordinator_origin=https://barycenter.relux.works
- recovery_id=rec_6e2f997262f719817c7891bea0098b1e
- node_token_fp=sha256:63caac25df7919b6   control_token_fp=sha256:ccd7379ee0786854

## Windows (DESKTOP-3PBO632, admin) — read via in-memory DPAPI Unprotect of %APPDATA%\Pulsar\credentials.v1.dpapi
- store: DPAPI file credentials.v1.dpapi (662 bytes, blob SHA-256 07DC6E09831DE45CA2A23EDB294226A97A0648A29BF4C8678A939AE351FE49F8; bundle version 1)
- envelope magic=BCDP version=1 payload_len=436
- orbit_id=10  slot=a  actor_id=21  role=primary  context=active
- coordinator_origin=https://barycenter.relux.works
- recovery_id=rec_6fcd1faee4f89bc0af8671b38b55eadc
- node_token_fp=sha256:f6f7d5e8c06d55e9   control_token_fp=sha256:32ba8289026a9e88

## Distinctness / no-pairing
- orbit 9 != orbit 10 ; actor 20 != actor 21 ; recovery ids differ ; all 4 token fingerprints differ.
- coordinator orbits count 9 -> 10 => a NEW Barycenter minted (not device pairing, which keeps same orbit).
- Windows %APPDATA%\Pulsar has no legacy credentials.json and no recovery-*.dpapi pending file; no cross-machine copy.
