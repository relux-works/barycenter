$ErrorActionPreference="SilentlyContinue"
$p = "C:\Users\admin\AppData\Local\Programs\Pulsar"
Write-Output "=== running candidate dir ==="
Get-ChildItem $p -Filter *.exe | ForEach-Object {
  $h=(Get-FileHash -Algorithm SHA256 $_.FullName).Hash
  Write-Output ($_.Name + "  bytes=" + $_.Length + "  sha256=" + $h)
}
Write-Output "=== MSIX package (for record) ==="
$pkg = Get-AppxPackage -Name "*PulsarBarycenter*" -ErrorAction SilentlyContinue
if($pkg){ Write-Output ("PackageFullName=" + $pkg.PackageFullName) } else { Write-Output "no MSIX" }
